import UIKit

var str = "Hello, playground"

for index in 1...6 {
    print("\(index) times 30 seconds is \(index * 30)")
}

var seconds = 190

if seconds <= 180 {
    print("Egg timer is going")
} else {
    print("Egg timer stopped")
}
